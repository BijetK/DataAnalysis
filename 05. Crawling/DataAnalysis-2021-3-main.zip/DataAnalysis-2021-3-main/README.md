# 데이터 분석 강좌
[데이터 사이언스 스쿨](https://datascienceschool.net/intro.html) 온라인 버전

## 멀티캠퍼스, 서울
### 빅데이터 기반 지능형 서비스 개발(2021.07 ~ 2021.12)

